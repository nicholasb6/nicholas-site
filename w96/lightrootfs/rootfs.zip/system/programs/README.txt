Welcome to Windows 96!

-- WHERE TO FIND PROGRAMS --

All of your programs are stored in this menu.
There are many preinstalled programs to explore, so go wild and find out what they do.

You can acquire new programs using the Package Manager, which you can find on the desktop or in Start > System.

-- FINAL WORD --

We hope you enjoy using Windows 96! Please let us know what you think, you can contact us on Discord, which you can find in the Wiki.