# Welcome to Windows 96!

Windows 96 is a Win9x-esque Web OS loaded with a bunch of programs and other fun stuff for you to use.

Any files you upload on the Windows 96 environment will NOT be uploaded to the cloud, everything is client side (unless you use our online services such as MsgRoom).

```
⚠ Be wary of users trying to get you to open random JS files, such files can be malicious and you may lose your data within Windows 96.
```

## Need help?

Open the `Docs/` folder on the desktop to view additional help for Windows 96.

## Have a question?

Generally, we advise you to talk in our Discord for help and support. You can find it [here](https://discord.gg/QxsW2pcwu6) (https://discord.gg/QxsW2pcwu6).

To report server outages, copyright issues, or other urgent problems, email us [here](mailto:ctm@windows96.net).

## Want to support us?

Windows 96 is a website continuously maintained and updated by a small group of artists and programmers. We also have to cover server costs and whatnot.

If you like what you see, go to Start > About Windows 96 > Support Us.

We are grateful for any amount that is given to us! Your gratitude will keep it all running smoothly!